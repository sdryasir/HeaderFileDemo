#ifndef HEADER_H
#define HEADER_H
#include<string>
using namespace std;
class Human{
	public:
		string name;
		string cnic;
		int age;
	public:
		Human(string name, string cnic, int age);
	
	public:
		void display();
};
#endif
