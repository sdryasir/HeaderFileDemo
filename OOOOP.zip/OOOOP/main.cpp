#include <iostream>
#include "Human.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Human h("Yasir Ali", "36521-02356689-2", 30);
	h.display();
	return 0;
}
