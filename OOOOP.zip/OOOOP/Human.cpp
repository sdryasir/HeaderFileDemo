#include<iostream>
#include "Human.h"

Human::Human(string name, string cnic, int age)
{
	this->name = name;
	this->cnic = cnic;
	this->age = age;
}

void Human::display(){
	cout<<name<<cnic<<age;
}
